//! Install-location prompt opened before starting a game download.
use super::Action;
use crate::model::GameStore;
use eframe::egui;
use std::path::Path;

pub fn show(
    ctx: &egui::Context,
    name: &str,
    store: GameStore,
    directory: &mut String,
    generation: u64,
    out: &mut Vec<Action>,
) {
    let mut open = true;
    let mut confirm = false;
    let mut dismiss = false;

    let id = egui::Id::new(("download_location", generation));
    let progress = ctx.animate_bool_with_time(id.with("open_animation"), true, 0.24);
    let eased = 1.0 - (1.0 - progress).powi(3);
    let size = egui::vec2(560.0, 240.0);
    let center = ctx.content_rect().center();
    let position = center - size * 0.5 + egui::vec2(0.0, 18.0 * (1.0 - eased));

    egui::Window::new("Choisir l'emplacement d'installation")
        .id(id)
        .collapsible(false)
        .resizable(false)
        .fixed_size(size)
        .fixed_pos(position)
        .open(&mut open)
        .show(ctx, |ui| {
            ui.set_width(520.0);
            ui.label(
                egui::RichText::new(format!("Installer {name}"))
                    .size(16.0)
                    .strong(),
            );
            ui.add_space(8.0);
            ui.label("Choisissez le dossier parent. Universal Downloader y créera un dossier au nom du jeu.");
            ui.add_space(8.0);
            ui.horizontal(|ui| {
                ui.add_sized(
                    [ui.available_width() - 92.0, 32.0],
                    egui::TextEdit::singleline(directory)
                        .hint_text("Chemin du dossier")
                        .vertical_align(egui::Align::Center),
                );
                if ui.add_sized([84.0, 32.0], egui::Button::new("Parcourir…")).clicked() {
                    let mut picker = rfd::FileDialog::new().set_title("Choisir le dossier d'installation");
                    if Path::new(directory.trim()).is_dir() {
                        picker = picker.set_directory(directory.trim());
                    }
                    if let Some(path) = picker.pick_folder() {
                        *directory = path.display().to_string();
                    }
                }
            });
            ui.add_space(6.0);
            ui.label(egui::RichText::new(match store {
                GameStore::Xbox => "Le paquet Xbox sera téléchargé dans ce dossier.",
                GameStore::Epic => "Les fichiers du jeu Epic seront installés dans ce dossier.",
            }).size(11.0).color(egui::Color32::GRAY));
            ui.add_space(12.0);
            ui.horizontal(|ui| {
                if ui.button("Annuler").clicked() {
                    dismiss = true;
                }
                let valid_directory = Path::new(directory.trim()).is_absolute();
                if ui
                    .add_enabled(valid_directory, egui::Button::new("Télécharger"))
                    .clicked()
                {
                    confirm = true;
                }
            });
        });

    if confirm {
        out.push(Action::ConfirmDownload {
            directory: directory.trim().to_owned(),
        });
    } else if dismiss || !open {
        out.push(Action::DismissDownload);
    }
}
